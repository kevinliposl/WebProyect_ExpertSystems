<footer style="margin: 0px; padding: 0px; width: 100%;">
    <div class="footer-link bg-black">
        <div class="container">
            <br>
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <li><a class="color-white link-red" href="?action=aboutUs">Quienes Somos</a></li>
                    </ul>
                    <div class="copyright">
                        <span class="color-grey-6">&copy; 2018 Todos los derechos reservados.</span>
                    </div>
                </div>
            </div>
            <br>
        </div>
    </div>    
</footer>
<script src="public/js/jquery.min.js"></script>
<script src="public/js/jquery-2.1.4.min.js"></script>
<script src="public/js/bootstrap.min.js"></script>
<script src="public/js/jquery-ui.min.js"></script>
<script src="public/js/idangerous.swiper.min.js"></script>
<script src="public/js/jquery.viewportchecker.min.js"></script>
<script src="public/js/isotope.pkgd.min.js"></script>
<script src="public/js/jquery.mousewheel.min.js"></script>
<script src="public/js/all.js"></script>

</body>
</html>
