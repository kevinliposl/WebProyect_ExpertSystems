package com.kevin.pablo.pktourism.Adapter;

import android.app.Activity;
import android.support.annotation.NonNull;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import com.kevin.pablo.pktourism.Entities.User;
import com.kevin.pablo.pktourism.R;

import java.util.ArrayList;

public class UserProfileAdapterRecyclerView extends RecyclerView.Adapter<UserProfileAdapterRecyclerView.UserProfileViewHolder>  {

    private ArrayList<User> users;

    private int resource;

    private Activity activity;

    /**
     * Constructor
     * @param users
     * @param resource
     * @param activity
     */
    public UserProfileAdapterRecyclerView(ArrayList<User> users, int resource, Activity activity) {
        this.users = users;
        this.resource = resource;
        this.activity = activity;
    }

    public class UserProfileViewHolder extends RecyclerView.ViewHolder{

        private TextView name;
        private TextView lastName;
        private TextView email;
        private RadioButton styleOne;
        private RadioButton styleTwo;
        private RadioButton styleThree;

        public UserProfileViewHolder(View itemView) {
            super(itemView);

            this.name = (TextView) itemView.findViewById(R.id.name);
            this.lastName = (TextView) itemView.findViewById(R.id.lastName);
            this.email = (TextView) itemView.findViewById(R.id.email);
            this.styleOne = (RadioButton) itemView.findViewById(R.id.radioButton);
            this.styleTwo = (RadioButton) itemView.findViewById(R.id.radioButton2);
            this.styleThree = (RadioButton) itemView.findViewById(R.id.radioButton3);
        }

    }

    @NonNull
    @Override
    public UserProfileAdapterRecyclerView.UserProfileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(resource, parent, false);
        return new UserProfileAdapterRecyclerView.UserProfileViewHolder(view);
    }

    /**
     *
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(@NonNull UserProfileAdapterRecyclerView.UserProfileViewHolder holder, int position) {
        User user = users.get(position);
        holder.name.setText(user.getName());
        holder.lastName.setText(user.getLastName());
        holder.email.setText(""+user.getEmail());
        switch(user.getStyle()){
            case "Aventurero":
                holder.styleOne.setChecked(true);
                break;
            case "Conservador":
                holder.styleTwo.setChecked(true);
                break;
            case "Investigador":
                holder.styleThree.setChecked(true);
                break;
            default:
        }
    }

    /**
     * Funcion para obtener numero
     * @return
     */
    @Override
    public int getItemCount() {
        return users.size();
    }

}
