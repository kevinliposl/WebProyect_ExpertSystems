package com.kevin.pablo.pktourism.Util;

import com.kevin.pablo.pktourism.Entities.User;

public class Utility {

    public static User USER_LOGIN = new User();
}
