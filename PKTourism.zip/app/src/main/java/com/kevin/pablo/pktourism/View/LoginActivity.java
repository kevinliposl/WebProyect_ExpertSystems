package com.kevin.pablo.pktourism.View;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.kevin.pablo.pktourism.Entities.User;
import com.kevin.pablo.pktourism.R;
import com.kevin.pablo.pktourism.Util.Utility;
import com.kevin.pablo.pktourism.Util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void goCreateAccount(View view){
        Intent intent = new Intent(this, CreateAccountActivity.class);
        startActivity(intent);
    }

    public void goHome(View view){

        EditText editTextUsname = (EditText) findViewById(R.id.username);
        EditText editTextUspd = (EditText) findViewById(R.id.password);

        Utility.USER_LOGIN.setEmail(editTextUsname.getText().toString());
        Utility.USER_LOGIN.setPassword(editTextUspd.getText().toString());

        initData();

    }

    public void initData(){
        Toast toast =
                Toast.makeText(this.getApplicationContext(),
                        "Por favor, espera", Toast.LENGTH_SHORT);
        toast.show();

        JsonObjectRequest jsonObjectRequest= new JsonObjectRequest(
                Request.Method.GET,
                "http://pktourism.000webhostapp.com/?controller=AppUser&action=signIn&mail="+Utility.USER_LOGIN.getEmail()+"&password="+Utility.USER_LOGIN.getPassword(),
                null,
                new Response.Listener<JSONObject>(){
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if(response.getJSONObject("result").getString("result").equals("1")){
                                Utility.USER_LOGIN.setLog(true);
                                Intent intent = new Intent(getBaseContext(), ContainerActivity.class);
                                startActivity(intent);

                            }else {
                                Toast toast =
                                        Toast.makeText(getBaseContext().getApplicationContext(),
                                                "Error al inicio de sesión, revise sus credenciales", Toast.LENGTH_LONG);
                                toast.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Log.d("JSON","Respuesta "+ error.toString());
                    }
                }
        );

        VolleySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest);
    }
}
