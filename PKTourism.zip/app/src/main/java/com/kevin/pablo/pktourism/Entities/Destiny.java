package com.kevin.pablo.pktourism.Entities;

public class Destiny {

    private String id;
    private String name;
    private String description;
    private String attraction;
    private String type;
    private String location;
    private String latitude;
    private String longitude;
    private String imageLink;
    private String videoLink;

    private int views;
    private int votes;
    private int stars;

    private double price;

    /**
     * Constructor vacio
     */
    public Destiny() {

        this.id = "";
        this.name = "";
        this.description = "";
        this.attraction = "";
        this.type = "";
        this.location = "";
        this.latitude = "";
        this.longitude = "";
        this.imageLink = "";
        this.videoLink = "";

        this.views = 0;
        this.votes = 0;
        this.stars = 0;

        this.price = 0;
    }

    /**
     * Constractor sobrecargado
     * @param id
     * @param name
     * @param description
     * @param attraction
     * @param type
     * @param location
     * @param latitude
     * @param longitude
     * @param imageLink
     * @param videoLink
     * @param views
     * @param votes
     * @param stars
     * @param price
     */
    public Destiny(String id, String name,String description, String attraction, String type, String location, String latitude, String longitude, String imageLink, String videoLink, int views, int votes, int stars, double price) {

        this.id = id;
        this.name = name;
        this.description = description;
        this.attraction = attraction;
        this.type = type;
        this.location = location;
        this.latitude = latitude;
        this.longitude = longitude;
        this.imageLink = imageLink;
        this.videoLink = videoLink;

        this.views = views;
        this.votes = votes;
        this.stars = stars;

        this.price = price;
    }

    /**
     * Constructor sobrecargado
     * @param name
     * @param description
     * @param location
     * @param imageLink
     * @param price
     */
    public Destiny(String name,String description, String location, String imageLink, double price) {
        this.name = name;
        this.description = description;
        this.location = location;
        this.imageLink = imageLink;
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAttraction() {
        return attraction;
    }

    public void setAttraction(String attraction) {
        this.attraction = attraction;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getVideoLink() {
        return videoLink;
    }

    public void setVideoLink(String videoLink) {
        this.videoLink = videoLink;
    }

    public int getViews() {
        return views;
    }

    public void setViews(int views) {
        this.views = views;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

}
