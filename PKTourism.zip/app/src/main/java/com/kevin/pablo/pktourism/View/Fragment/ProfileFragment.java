package com.kevin.pablo.pktourism.View.Fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.kevin.pablo.pktourism.Adapter.UserProfileAdapterRecyclerView;
import com.kevin.pablo.pktourism.Entities.User;
import com.kevin.pablo.pktourism.R;
import com.kevin.pablo.pktourism.Util.Utility;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment {

    private View view;

    public ProfileFragment(){
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.view = inflater.inflate(R.layout.fragment_profile2, container, false);

        initData();

        showToolbar("",false);

        return this.view;
    }

    public ArrayList<User> buildUserData(){
        ArrayList<User> users = new ArrayList<>();
        users.add(Utility.USER_LOGIN);

        return users;
    }


    public void showToolbar(String title, boolean upButton){
        Toolbar toolbar = (Toolbar) this.view.findViewById(R.id.toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(title);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(upButton);

    }

    public void initRecycler(){
        RecyclerView userProfileRecycler = (RecyclerView) this.view.findViewById(R.id.userProfileRecycler);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        userProfileRecycler.setLayoutManager(linearLayoutManager);

        UserProfileAdapterRecyclerView userProfileAdapterRecyclerView = new UserProfileAdapterRecyclerView(
                buildUserData() , R.layout.cardview_userprofile, getActivity()
        );

        userProfileRecycler.setAdapter(userProfileAdapterRecyclerView);
    }

    public void initData(){
        Toast toast =
                Toast.makeText(this.view.getContext().getApplicationContext(),
                        "Por favor, espera", Toast.LENGTH_LONG);
        toast.show();

        RequestQueue queue = new Volley().newRequestQueue(getContext());

        JsonObjectRequest jsonObjectRequest= new JsonObjectRequest(
                Request.Method.GET,
                "http://pktourism.000webhostapp.com/?controller=AppUser&action=selectUser&mail="+ Utility.USER_LOGIN.getEmail(),
                null,
                new Response.Listener<JSONObject>(){
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Utility.USER_LOGIN.setName(response.getJSONObject("result").getString("name"));
                            Utility.USER_LOGIN.setLastName(response.getJSONObject("result").getString("lastname"));
                            Utility.USER_LOGIN.setStyle(response.getJSONObject("result").getString("style"));

                            initRecycler();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Log.d("JSON","Respuesta "+ error.toString());
                    }
                }
        );
        queue.add(jsonObjectRequest);
    }

    public void getText(){
        EditText editTextUsmail = (EditText) getActivity().findViewById(R.id.email);
        EditText editTextUsname = (EditText) getActivity().findViewById(R.id.name);
        EditText editTextUslastname = (EditText) getActivity().findViewById(R.id.lastName);

        RadioGroup radioGroup = (RadioGroup) getActivity().findViewById(R.id.rgStyleCardview);

        int radioButtonId = radioGroup.getCheckedRadioButtonId();

        RadioButton radioButton = (RadioButton) radioGroup.findViewById(radioButtonId);

        Utility.USER_LOGIN.setEmail(editTextUsmail.getText().toString());
        Utility.USER_LOGIN.setName(editTextUsname.getText().toString());
        Utility.USER_LOGIN.setLastName(editTextUslastname.getText().toString());
        Utility.USER_LOGIN.setStyle(radioButton.getText().toString());
    }
}
