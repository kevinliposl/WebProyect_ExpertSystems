package com.kevin.pablo.pktourism.View;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.kevin.pablo.pktourism.R;
import com.kevin.pablo.pktourism.Util.Utility;
import com.kevin.pablo.pktourism.Util.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

public class CreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        showToolbar(getResources().getString(R.string.toolbar_tittle_createaccount), true);

        Button boton1 = (Button)findViewById(R.id.joinUs);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createAccount();
            }
        });
    }

    public void showToolbar(String title, boolean upButton){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(title);
        getSupportActionBar().setDisplayHomeAsUpEnabled(upButton);

    }

    public void createAccount(){
        Toast toast =
                Toast.makeText(this.getApplicationContext(),
                        "Por favor, espera...", Toast.LENGTH_SHORT);
        toast.show();

        getText();

        JsonObjectRequest jsonObjectRequest= new JsonObjectRequest(
                Request.Method.GET,
                "http://pktourism.000webhostapp.com/?controller=AppUser&action=signUp&mail="+Utility.USER_LOGIN.getEmail()
                        +"&password="+Utility.USER_LOGIN.getPassword()
                        +"&name="+Utility.USER_LOGIN.getName()
                        +"&lastname="+Utility.USER_LOGIN.getLastName()
                        +"&style="+Utility.USER_LOGIN.getStyle(),
                null,
                new Response.Listener<JSONObject>(){
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.d("RESPUESTA", "http://pktourism.000webhostapp.com/?controller=AppUser&action=signUp&mail="+Utility.USER_LOGIN.getEmail()
                                +"&password="+Utility.USER_LOGIN.getPassword()
                                +"&name="+Utility.USER_LOGIN.getName()
                                +"&lastname="+Utility.USER_LOGIN.getLastName()
                                +"&style="+Utility.USER_LOGIN.getStyle());
                        try {
                            if(response.getString("result").equals("1")){
                                Toast toast =
                                        Toast.makeText(getBaseContext().getApplicationContext(),
                                                "¡Creación con éxito!", Toast.LENGTH_LONG);
                                toast.show();
                                finish();

                            }else {
                                Toast toast =
                                        Toast.makeText(getBaseContext().getApplicationContext(),
                                                "Error al crear la cuenta, revise sus credenciales", Toast.LENGTH_LONG);
                                toast.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Log.d("JSON","Respuesta "+ error.toString());
                    }
                }
        );

        VolleySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest);
    }

    public void getText(){
        EditText editTextUsmail = (EditText) findViewById(R.id.newEmail);
        EditText editTextUsname = (EditText) findViewById(R.id.newName);
        EditText editTextUslastname = (EditText) findViewById(R.id.newLastName);
        EditText editTextUspd = (EditText) findViewById(R.id.newPassword);

        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.rgStyle);

        int radioButtonId = radioGroup.getCheckedRadioButtonId();

        RadioButton radioButton = (RadioButton) radioGroup.findViewById(radioButtonId);

        Utility.USER_LOGIN.setEmail(editTextUsmail.getText().toString());
        Utility.USER_LOGIN.setName(editTextUsname.getText().toString());
        Utility.USER_LOGIN.setLastName(editTextUslastname.getText().toString());
        Utility.USER_LOGIN.setPassword(editTextUspd.getText().toString());
        Utility.USER_LOGIN.setStyle(radioButton.getText().toString());
    }
}
