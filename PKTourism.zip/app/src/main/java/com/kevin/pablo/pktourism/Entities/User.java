package com.kevin.pablo.pktourism.Entities;

public class User {

    private String name;
    private String password;
    private String lastName;
    private String email;
    private String style;
    private boolean log;


    public User() {
        this.name = "";
        this.password = "";
        this.lastName = "";
        this.email = "";
        this.style = "";
        this.log = false;
    }

    public User(String name, String lastName, String email, String style) {
        this.name = name;
        this.lastName = lastName;
        this.email = email;
        this.style = style;
        this.log = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public boolean isLog() {
        return log;
    }

    public void setLog(boolean log) {
        this.log = log;
    }
}
