package com.kevin.pablo.pktourism.View;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.Window;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;
import com.kevin.pablo.pktourism.R;
import com.kevin.pablo.pktourism.Util.BottomNavigationViewHelper;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private BottomNavigationViewEx bottomNavigationViewEx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    private void setupBottomNavigationView(){
        //this.bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottom_no_user_navigation_view);
        //BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
    }
}
