package com.kevin.pablo.pktourism.View.Fragment;


import android.app.FragmentTransaction;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.transition.Fade;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.edmodo.rangebar.RangeBar;
import com.kevin.pablo.pktourism.Entities.Destiny;
import com.kevin.pablo.pktourism.R;
import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;

import java.util.ArrayList;


public class UserSearchFragment extends Fragment {


    private View view;

    private ArrayList<String> spinnerListLocation = new ArrayList<String>();

    private ArrayList<String> spinnerListAttraction = new ArrayList<String>();

    private ArrayList<String> spinnerListType = new ArrayList<String>();

    private ArrayList<String> spinnerListCalification = new ArrayList<String>();

    public UserSearchFragment() {
        this.spinnerListLocation.add("Guanacaste");
        this.spinnerListLocation.add("San José");
        this.spinnerListLocation.add("Cartago");
        this.spinnerListLocation.add("Limón");
        this.spinnerListLocation.add("Puntarenas");
        this.spinnerListLocation.add("Alajuela");
        this.spinnerListLocation.add("Heredia");

        this.spinnerListAttraction.add("No importa");
        this.spinnerListAttraction.add("Parques Nacionales");
        this.spinnerListAttraction.add("Ruinas y lugares históricos");
        this.spinnerListAttraction.add("Galerías y Museos");
        this.spinnerListAttraction.add("Jardines botánicos y zoológicos");
        this.spinnerListAttraction.add("Miradores");
        this.spinnerListAttraction.add("Hotel");
        this.spinnerListAttraction.add("Restaurante");

        this.spinnerListType.add("No importa");
        this.spinnerListType.add("Urbana");
        this.spinnerListType.add("Costera");
        this.spinnerListType.add("De montaña");

        this.spinnerListCalification.add("No importa");
        this.spinnerListCalification.add("1");
        this.spinnerListCalification.add("2");
        this.spinnerListCalification.add("3");
        this.spinnerListCalification.add("4");
        this.spinnerListCalification.add("5");

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        this.view = inflater.inflate(R.layout.fragment_user_search, container, false);

        this.showToolbar("Advance Search", false);
        this.initSpinner();
        this.initRangeBar();

        Button boton1 = (Button) this.view.findViewById(R.id.search);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                advanceSearchNow();
            }
        });

        return this.view;
    }

    public void showToolbar(String title, boolean upButton){
        Toolbar toolbar = (Toolbar) this.view.findViewById(R.id.toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(title);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(upButton);

    }

    public void initRangeBar(){
        RangeBar rangebar = (RangeBar) this.view.findViewById(R.id.RangeBar);
        rangebar.setTickCount(1000);
        rangebar.setTickHeight(25);
        rangebar.setBarWeight(0);
        rangebar.setBarColor(229999999);

        rangebar.setOnRangeBarChangeListener(new RangeBar.OnRangeBarChangeListener() {
            @Override
            public void onIndexChangeListener(RangeBar rangeBar, int leftThumbIndex, int rightThumbIndex) {
                TextView textView = (TextView) view.findViewById(R.id.leftRange);
                textView.setText("$ "+leftThumbIndex);

                textView = (TextView) view.findViewById(R.id.rightRange);
                textView.setText("$ "+rightThumbIndex);
            }
        });
    }

    public void initSpinner(){
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this.view.getContext(), android.R.layout.simple_dropdown_item_1line, this.spinnerListLocation);
        MaterialBetterSpinner materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_location);
        materialDesignSpinner.setAdapter(arrayAdapter);

        arrayAdapter = new ArrayAdapter<String>(
                this.view.getContext(), android.R.layout.simple_dropdown_item_1line, this.spinnerListAttraction);
        materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_attaction);
        materialDesignSpinner.setAdapter(arrayAdapter);

        arrayAdapter = new ArrayAdapter<String>(
                this.view.getContext(), android.R.layout.simple_dropdown_item_1line, this.spinnerListType);
        materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_type);
        materialDesignSpinner.setAdapter(arrayAdapter);

        arrayAdapter = new ArrayAdapter<String>(
                this.view.getContext(), android.R.layout.simple_dropdown_item_1line, this.spinnerListCalification);
        materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_calification);
        materialDesignSpinner.setAdapter(arrayAdapter);
    }

    public void advanceSearchNow(){
        String vars[] = prepareData();

        Fragment fragment  = new SearchResultFragment();

        Bundle args = new Bundle();
        args.putStringArray("vars", vars);
        fragment.setArguments(args);

        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE).addToBackStack(null).commit();
    }

    public String[] prepareData(){
        String vars[] = new String[5];

        MaterialBetterSpinner materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_location);

        vars[0] = materialDesignSpinner.getText().toString();

        materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_attaction);

        vars[1] = materialDesignSpinner.getText().toString();

        materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_type);

        vars[2] = materialDesignSpinner.getText().toString();

        materialDesignSpinner = (MaterialBetterSpinner)
                this.view.findViewById(R.id.android_material_design_spinner_calification);

        vars[3] = materialDesignSpinner.getText().toString();

        TextView textView = (TextView) view.findViewById(R.id.rightRange);

        vars[4] = textView.getText().toString();

        return vars;
    }
}
