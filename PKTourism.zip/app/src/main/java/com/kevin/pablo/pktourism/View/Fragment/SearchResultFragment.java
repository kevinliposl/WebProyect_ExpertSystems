package com.kevin.pablo.pktourism.View.Fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.kevin.pablo.pktourism.Adapter.DestinyAdapterRecyclerView;
import com.kevin.pablo.pktourism.Entities.Destiny;
import com.kevin.pablo.pktourism.R;
import com.kevin.pablo.pktourism.Util.Utility;
import com.kevin.pablo.pktourism.Util.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class SearchResultFragment extends Fragment {

    final ArrayList<Destiny> destinies = new ArrayList<>();

    private String vars[];
    private View view;

    public SearchResultFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        this.view = inflater.inflate(R.layout.fragment_search_result, container, false);

        this.showToolbar("Results", false);

        buildDestinies();

        return view;
    }

    public void showToolbar(String title, boolean upButton){
        Toolbar toolbar = (Toolbar) this.view.findViewById(R.id.toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(title);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(upButton);

    }

    public void buildDestinies(){
        final Bundle bundle = getArguments();
        String vars[]= bundle != null ? bundle.getStringArray("vars") : null;

        Toast toast =
                Toast.makeText(this.view.getContext().getApplicationContext(),
                        "Por favor, espera", Toast.LENGTH_LONG);
        toast.show();

        String url = "https://pktourism.000webhostapp.com/?controller=AppDestiny&action=advancedSearch" +
                "&location="+vars[0]+"&attraction="+vars[1]+"&type="+vars[2]+"&stars="+vars[3]+"&style="+Utility.USER_LOGIN.getStyle()+"&price="+vars[4];

        url = url.replace(" ", "%20");

        RequestQueue queue = new Volley().newRequestQueue(getContext());

        JsonArrayRequest jsonObjectRequest= new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>(){
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i< response.length();i++){
                                destinies.add(new Destiny(response.getJSONObject(i).get("name").toString(),
                                        response.getJSONObject(i).get("description").toString(),
                                        response.getJSONObject(i).get("location").toString(),
                                        response.getJSONObject(i).get("url_photo").toString(),
                                        Float.parseFloat(response.getJSONObject(i).get("price").toString())));
                            }

                            initRecycler(destinies);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Log.d("JSON","Respuesta "+ error.toString());
                    }
                }
        );
        VolleySingleton.getInstance(getContext()).addToRequestQueue(jsonObjectRequest);
    }

    public void initRecycler(ArrayList<Destiny> buildDestinies){
        RecyclerView destinyRecycler = (RecyclerView) view.findViewById(R.id.searchResultRecycler);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        destinyRecycler.setLayoutManager(linearLayoutManager);

        DestinyAdapterRecyclerView destinyAdapterRecyclerView = new DestinyAdapterRecyclerView(
                buildDestinies , R.layout.cardview_destiny, getActivity()
        );

        destinyRecycler.setAdapter(destinyAdapterRecyclerView);
    }

}
