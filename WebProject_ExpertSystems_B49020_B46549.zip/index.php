<?php
require 'libs/FrontController.php';
require 'libs/SSession.php';
FrontController::main();
SSession::getInstance();
