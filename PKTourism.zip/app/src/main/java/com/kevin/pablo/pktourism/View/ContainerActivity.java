package com.kevin.pablo.pktourism.View;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Fade;
import android.view.View;

import com.kevin.pablo.pktourism.R;
import com.kevin.pablo.pktourism.View.Fragment.HomeFragment;
import com.kevin.pablo.pktourism.View.Fragment.ProfileFragment;
import com.kevin.pablo.pktourism.View.Fragment.SearchResultFragment;
import com.kevin.pablo.pktourism.View.Fragment.UserSearchFragment;
import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnTabSelectListener;

public class ContainerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_container);

        BottomBar bottomBar = (BottomBar) findViewById(R.id.userBottonbar);
        bottomBar.setDefaultTab(R.id.userHome);

        bottomBar.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelected(int tabId) {
                Fragment fragment = new Fragment();
                switch (tabId){
                    case R.id.userHome:
                        fragment = new HomeFragment();
                        break;
                    case R.id.userProfile:
                        fragment  = new ProfileFragment();
                        break;
                    case R.id.userSearch:
                        fragment  = new UserSearchFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE).addToBackStack(null).commit();
            }
        });
    }

    public void goMap(View v){
        Intent intent = new Intent(this, MapsActivity.class);
        intent.putExtra("v", "9.900650");
        intent.putExtra("vOne", "-83.672635");
        startActivity(intent);
    }
}
